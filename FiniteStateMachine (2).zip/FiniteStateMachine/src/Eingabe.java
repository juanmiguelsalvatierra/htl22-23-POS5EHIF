public enum Eingabe {
    Eins(), Zwei(), Knopf();
}
