public enum Ausgabe {
    Null(), Eins(), Zwei(), Drei(), Drink(), Retour(), Error();

}
