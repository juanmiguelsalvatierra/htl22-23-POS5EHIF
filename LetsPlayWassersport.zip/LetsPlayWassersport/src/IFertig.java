public interface IFertig {
    void kentern(IWind boot);
    void finish(IWind boot);
}
