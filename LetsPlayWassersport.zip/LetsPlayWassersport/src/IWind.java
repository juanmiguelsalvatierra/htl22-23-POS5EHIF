public interface IWind {
    void wind() throws InterruptedException;
}
