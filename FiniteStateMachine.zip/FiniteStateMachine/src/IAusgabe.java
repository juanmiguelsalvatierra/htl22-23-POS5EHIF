public interface IAusgabe {
    void Ausgabe(Ausgabe[] a);
}
