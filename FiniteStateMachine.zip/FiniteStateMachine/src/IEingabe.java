public interface IEingabe {
    void Eingabe(Eingabe e);
}
