public enum EEingabe {
    Eins, Zwei, Knopf;
}
