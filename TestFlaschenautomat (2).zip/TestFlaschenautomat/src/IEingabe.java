public interface IEingabe {
    void Eingabe(EEingabe eingabe);
}
