public enum Zustand {
    Start(0), Z1(1), Z2(2), Z3(3), ZRetour(4);

    int index;

    Zustand(int index) {
        this.index = index;
    }
}
