public enum Ausgabe {
    Eins(), Zwei(), Drei(), Drink(), Retour(), Error();

}
