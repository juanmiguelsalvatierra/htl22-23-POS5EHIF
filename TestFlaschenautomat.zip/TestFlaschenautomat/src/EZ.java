public class EZ {
    public EEingabe eing;
    public EZustand zust;

    public EZ(EEingabe eing, EZustand zust){
        this.eing = eing;
        this.zust = zust;
    }
}
