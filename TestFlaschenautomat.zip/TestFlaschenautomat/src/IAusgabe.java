public interface IAusgabe {
    void Ausgabe(EZustand zustand);
}
