public enum EAusgabe {
    Null, Error, Flasche, Eins, Zwei, Drei, Return;
}
